# Plan de continuidad · App de Althea Formación

**Versión del plan:** 1 · 22/11/2026  
**Titular:** Estefanía Pérez Busati (Fani) · Althea Formación · Chiclana  
**App:** https://horarios.altheaformacion.com  

> Este plan va dentro de cada copia de seguridad. Si lo estás leyendo desde el pen, en esta misma copia tienes también los datos, el código de la app, las reglas de la base de datos, el programa para restaurarlo todo y el manual técnico.

---

## 1. Lo primero: la app no depende de Claude

La app funciona sola. Claude solo se ha usado para **hacerle cambios**. Si Claude dejara de existir, la app seguiría funcionando igual; solo costaría más cambiarla.

Todo está en cuentas **tuyas**:

| Qué | Dónde | Cuenta | Para qué sirve |
|---|---|---|---|
| **Código de la app** | GitHub · repositorio `horarios-althea` (público) | `mostradoraltheaformacion-coder` (se entra con la cuenta de Google) | La web que se ve. Cada versión se sube aquí. |
| **Datos** (alumnos, recibos, caja, gastos, facturas, fichajes…) | Firebase (Google) · proyecto `althea-horarios` · plan gratuito «Spark» | Cuenta de Google `mostradoraltheaformacion@gmail.com` | La base de datos y los usuarios de la app. |
| **Dominio** `horarios.altheaformacion.com` | Loading.es → Plesk → altheaformacion.com → DNS | Área de cliente de Loading | Hace que la dirección apunte a GitHub. |
| Web principal y correo | Wix (web) y Loading (correo) | — | No tienen nada que ver con la app. **No tocar.** |
| Reserva | Cloudflare Pages · `horarios-althea.pages.dev` | Cuenta de Cloudflare | Copia antigua, por si GitHub fallara. |
| Programa de recibos y facturas actual | Argos | — | Hasta que la app facture de verdad, y unos meses después por seguridad. |
| Asesoría | A3 Asesores | Usuario `asesoria` en la app (solo lectura) | Reciben cada mes el informe. |
| Notas de cómo se hizo la app | claude.ai · proyecto «2 fase de app althea» | Tu cuenta de Claude | Historial de decisiones. Lo importante está resumido en el MANUAL-TECNICO de esta copia. |

---

## 2. Qué guardar y dónde

**A. Sobre cerrado, en papel** (en un sitio seguro, **separado del pen**):

- Cuenta de Google: correo, clave y **códigos de recuperación** de la verificación en dos pasos.
- GitHub: usuario, clave y **códigos de recuperación** (se activó con Google Authenticator el 15/11/2026).
- Loading.es: usuario y clave del área de cliente.
- Cloudflare: usuario y clave.
- Clave de **dirección** de la app.
- **Contraseña de BitLocker del pen.**
- Nombre y teléfono de la **persona de confianza** (apartado 3).

**B. El pen** (cifrado con BitLocker: botón derecho sobre el pen → «Activar BitLocker»):

- Las copias de seguridad de la app: los archivos `althea-copia-AAAA-MM-DD.zip`. Guarda **al menos las 4 últimas** y una de cada fin de mes.
- **Ojo:** la copia lleva datos personales de alumnos y familias y las claves de la app. Por eso el pen va cifrado.

**C. Segunda copia** en la nube (Google Drive u otra), por si se pierde el pen. Lo ideal es subir el .zip dentro de una carpeta que no se comparta con nadie.

**Nunca** subas a GitHub nada que no sea de la web: el repositorio es público.

---

## 3. Persona de confianza

Elige a una persona que pueda entrar si a ti te pasara algo:

- En Google: **Cuenta de Google → Datos y privacidad → «Hacer un plan para tu cuenta digital» (Administrador de cuenta inactiva)**. Pon a esa persona; si tu cuenta no se usa en X meses, recibirá acceso.
- Dile dónde está el sobre y el pen.

Persona de confianza: ______________________ Teléfono: ______________

---

## 4. Rutina

**Cada semana** (la app lo recuerda en «Pendientes» si pasan más de 7 días):

1. Dirección → **Accesos → Copia de seguridad → «Descargar copia completa»**.
2. Copiar el .zip al pen y a la nube.

**Cada mes:**

1. Abrir la última copia del pen y comprobar que se abre (que el .zip no esté dañado).
2. Comprobar que la documentación de la copia está al día (en Accesos → Copia de seguridad sale la fecha). Si en el mes se han hecho cambios importantes en la app, pedir a Claude (o a quien lleve la app) el paquete `documentacion-althea.zip` nuevo y subirlo ahí.
3. Una vez al trimestre, hacer la copia **con PDFs y fotos** (casilla «Incluir PDFs y fotos»). Tarda más y ocupa más.

**Cada año:**

- Revisar que sigues pudiendo entrar en Google, GitHub, Loading y Cloudflare, y que los códigos del sobre siguen valiendo.
- Renovar el dominio `altheaformacion.com` en Loading.

---

## 5. Si algo pasa: qué hacer

### 5.1 Claude no está disponible

- La app **sigue funcionando**. No hay que hacer nada.
- Para cambios: cualquier **programador web** puede continuar (es HTML y JavaScript normales con Firebase), o cualquier otra herramienta de inteligencia artificial. Dale el **MANUAL-TECNICO.md** de la copia y la carpeta `app/`.

### 5.2 La web no carga

1. Prueba desde el móvil con datos (no con el wifi del centro) y en modo incógnito.
2. Mira en GitHub → `horarios-althea` → si el último cambio tiene un ✓ verde. Si tiene una ✗ roja, vuelve a subir los archivos de la última versión (están en la carpeta `app/` de la copia).
3. Si GitHub entero está caído: en Plesk (Loading), cambia el registro `horarios` (CNAME) a `horarios-althea.pages.dev`, y sube la carpeta `app/` a Cloudflare Pages. Ver el MANUAL-TECNICO, apartado «Alojamiento».

### 5.3 No puedes entrar en Google o GitHub

- Usa los **códigos de recuperación del sobre**.
- Si no funcionan: recuperación de cuenta de Google (https://accounts.google.com/signin/recovery) con el teléfono de recuperación.
- Mientras tanto la app sigue funcionando: solo no podrías hacer cambios.

### 5.4 Se han borrado o estropeado datos

- **No toques nada más** y avisa a quien lleve la app.
- Se restauran desde la última copia buena con el programa `restaurar/restaurar.mjs` (ver apartado 6, paso 6). Ojo: restaurar **sustituye** los documentos por los de la copia; lo que se hizo después de esa copia hay que volver a meterlo a mano.

### 5.5 Hay que empezar de cero en otro sitio
Sigue el **apartado 6**. Con la copia completa la app queda **igual**: mismas pantallas, mismos datos, mismos usuarios y claves.

### 5.6 No hay app durante unos días

- **Facturar y cobrar:** con **Argos**. Por eso conviene no darlo de baja de golpe en enero de 2027.
- **Horarios y teléfonos:** en la copia, `datos/` tiene todo; quien sepa de Excel o un programador puede sacarlo. Recomendación: una vez al mes, descargar desde la app en PDF o Excel lo básico (listado de alumnos con horario y teléfono, recibos pendientes).
- **Fichajes (desde el 1/1/2027):** apuntarlos en papel (nombre, día, hora de entrada y de salida, firma) y pasarlos después con «Corregir».

---

## 6. Reconstruir la app desde cero (para un programador o con ayuda)

Tiempo aproximado: 1–2 horas. Hace falta un ordenador con Node.js (https://nodejs.org).

1. **Firebase:** entra en https://console.firebase.google.com con la cuenta de Google. Si el proyecto `althea-horarios` sigue existiendo, úsalo y salta al paso 6. Si no, crea un proyecto nuevo:
   - Activa **Firestore Database** (modo producción, ubicación europea).
   - Activa **Authentication → Correo electrónico/contraseña**.
   - En **Authentication → Configuración → Dominios autorizados**, añade `horarios.altheaformacion.com`.
2. **Reglas:** Firestore → Reglas → pega el contenido de `reglas/firestore.rules` de la copia → Publicar.
3. **Conectar la app al proyecto:** en Firebase → Configuración del proyecto → «Tus apps» → añade una app web y copia su configuración. En `app/fb.js`, cambia la línea que empieza por `const CONFIG={` por la nueva configuración. (Si se usa el mismo proyecto, no hace falta.)
4. **Publicar la web:** en GitHub, crea un repositorio público (o usa el que hay), sube **todo lo de la carpeta `app/`** y activa **Configuración → Pages** (rama principal, carpeta raíz). En «Dominio personalizado» pon `horarios.altheaformacion.com` y marca «Aplicar HTTPS».
5. **Dominio:** en Plesk (Loading) → altheaformacion.com → DNS: registro `horarios`, tipo CNAME, valor `<usuario-de-github>.github.io`.
6. **Datos:** sigue `restaurar/LEEME.txt`. En resumen: descargar la «clave privada» de una cuenta de servicio de Firebase, descomprimir la copia y ejecutar `node restaurar.mjs clave.json carpeta-de-la-copia`.
7. **Entrar:** abre la app y entra con el usuario y la clave de **dirección**. La primera vez que entra cada persona, la app le crea su acceso sola con su usuario y clave de siempre. Al abrirla dirección, la app recalcula sola qué alumnos ve cada profesora.
8. **Comprobar:** alumnos, horarios, recibos, caja y facturas. Hacer una copia nueva.

---

## 7. Contactos

| Quién | Para qué | Contacto |
|---|---|---|
| A3 Asesores | Asesoría fiscal y laboral | __________________ |
| Loading.es | Dominio y correo | __________________ |
| Argos | Programa de recibos y facturas | __________________ |
| Programador de confianza (si lo hay) | Cambios y averías de la app | __________________ |
| Banco Sabadell | TPV y cuentas | __________________ |

---

## 8. Historial del plan

- **v1 · 22/11/2026:** primera versión. La copia de seguridad pasa a ser un .zip con datos, código, reglas, plan, manual técnico y programa de restauración.
