# Manual técnico · App de Althea Formación

**Actualizado:** 23/11/2026 (versión de la app 23nov-v158)  
**Para:** quien tenga que mantener o reconstruir la app (programador o herramienta de IA).  

La app es una web de una sola página, sin servidor propio: HTML + JavaScript en el navegador, con **Firebase** (Firestore + Authentication) como base de datos. Se aloja en **GitHub Pages** con el dominio `horarios.altheaformacion.com`. No hay paso de compilación: los archivos se suben tal cual.

---

## 1. Archivos (carpeta `app/` de la copia)

| Archivo | Qué es |
|---|---|
| `index.html` | La app (fase 1: horarios, faltas, cambios, asistencia, alumnos, accesos, recibos básicos, lista de espera, citas…) con su CSS y la mayor parte del JavaScript. Define `APP_VER`. |
| `gestion.js` | Fase 2: caja, gastos y banco, facturación, tarifas, nóminas, fichajes, impuestos, asesoría, rentabilidad, pendientes de dirección, descuadres, cuadre con Argos, copia de seguridad completa. |
| `fb.js` | Conexión con Firebase (módulo ES). Contiene `CONFIG` del proyecto, el acceso (usuario + clave → correo interno), el reparto de cada alumno en `alumnos/<id>` + `privado/<id>`, los archivos (PDF y fotos) troceados en Firestore y `window.claude.use(…)` (db, user, assets, downloads). |
| `manifest.webmanifest`, `icono.png`, `icono-192.png` | App instalable en el móvil. |
| `fachada.jpg` | Foto de la página de citas. |
| `ayuda-alumnos.mp4`, `ayuda-asesoria.mp4` | Vídeos de ayuda. |
| `CNAME` | `horarios.altheaformacion.com` (para GitHub Pages). |
| `_headers` | Cabeceras para Cloudflare (GitHub Pages no lo lee; la protección anti-iframe está en `index.html`). |

**Versionado:** en cada versión se cambia a la vez `APP_VER` y el `?v=` de `<script src="gestion.js?v=…">` y `fb.js?v=…` en `index.html` (si no, el navegador mezcla versiones por la caché de GitHub Pages). Se sube siempre `index.html`, aunque solo cambie otro archivo.

**Bibliotecas externas** (se cargan desde CDN cuando hacen falta): Firebase 10.12.2 (gstatic), pdf.js (leer PDF de Argos y del banco), SheetJS/xlsx (Excel), JSZip 3.10.1, pdf-lib 1.17.1 (partir PDF de facturas).

---

## 2. Acceso y perfiles

- Cada persona entra con **usuario + clave**. `fb.js` lo convierte en un correo interno `<usuario>.<hash>@acceso.altheaformacion.com` y una contraseña derivada, y entra en Firebase Authentication (correo/contraseña). Si la cuenta de Auth no existe, la crea sola (por eso, al restaurar en un proyecto nuevo, basta con restaurar `claves`).
- `claves/<usuario>` = {clave, rol, profe | alumno, bloqueado…}. `cuentas/<uid>` enlaza la cuenta de Auth con el usuario.
- Perfiles (`rol`): `dir` (dirección), `mos` (recepción / mostrador), `profe` (profesoras), `alumno` (familias), `ase` (asesoría A3, solo lectura). Ainea es `profe` con permisos extra (`esPlus` en las reglas: ve recibos y descuadres).
- La primera instalación: `publico/instalado` + crear el primer usuario de dirección (lo permiten las reglas una sola vez).
- Seguridad real = **reglas de Firestore** (`reglas/firestore.rules`). La pantalla solo esconde cosas; lo que protege los datos son las reglas.

## 3. Datos (colecciones de Firestore)

| Colección | Contenido |
|---|---|
| `alumnos/<id>` | Lo que ven sus profesoras: nombre, clases, faltas, asistencia, extras, puntuales, teléfonos, `profes` y `_d` (los calcula dirección sola). Campos: ver `CORE` en `fb.js`. |
| `privado/<id>` | El resto del alumno: recibos, matrículas, tarifa, inscripciones, datos personales, beca, baja… |
| `claves`, `cuentas`, `altas` | Usuarios, cuentas y altas de familias. |
| `config/<doc>` | Ajustes: `recibos` (tarifas, pilotoHX, formas que se facturan…), `copias`, `continuidad` (plan, manual y reglas para la copia), `kiosko`, `cajaConceptos`, `banco`… |
| `publico/<doc>` | Datos que leen todos los usuarios válidos (p. ej. `datos.profesUid`). |
| `buzon`, `buzonProf`, `buzonAl`, `mensajes` | Peticiones de familias y profesoras (cambios, asistencias, horas extra…) que dirección o recepción aplican a la ficha. |
| `preins` | Preinscripción por enlace (reserva 48 h, firma, Bizum). |
| `eventos`, `eventosNotas`, `citas` | Entrevistas, evaluaciones y sesiones psicopedagógicas; confirmación de citas por WhatsApp. |
| `plazas` | Lista de espera de huecos (Rosa, Fani, Elena, Lorena). |
| `avisosProf` | Avisos de las profesoras desde la ficha (añade o quita una clase, pasa a otra profesora, baja…). Los cierran dirección o Ainea (pestaña «Avisos»). |
| `caja` | Cobros, aperturas, apuntes, retiradas, cierres, anulaciones (no se pueden cambiar). Real desde el 1/1/2027. |
| `banco/<AAAA-MM>` | Movimientos del Sabadell, categorías, justificantes, caja de Argos (`argosCaja`), descuadres (`desc`). |
| `ventas/<AAAA-MM>` | Facturas de venta de Argos subidas (listado + PDF). |
| `facturas` / `facturasPrueba` | Facturas simplificadas de la app (reales desde 2027, inalterables; de prueba en 2026). Huella encadenada (Verifactu). |
| `facturasTaller` | Facturas de talleres al Ayuntamiento y entidades. |
| `nominas`, `impuestos`, `asesoria` | Nóminas y listado de costes, impuestos (los pone A3), copias enviadas a la asesoría. |
| `fichajes`, `fichPin` | Registro de jornada (desde 1/1/2027; solo se crean, hora del servidor) y PIN de cada profesora. |
| `archivos/<id>` (+ `p/<n>`) | PDF y fotos guardados dentro de Firestore como dataURL, troceados en partes de 700.000 caracteres si son grandes. |

## 4. Pantallas (pestañas de dirección)
Semana · Pendientes · Alumnos · Faltas · Cambios · Sesiones · Asistencia · Conflictos · Mensajes · Recibos · Caja · Gastos · Descuadres · Facturación · Tarifas · Fichajes · Cuadre Argos · Calendario · Accesos. Las profesoras, recepción, familias y asesoría ven solo lo suyo.

## 5. Procesos importantes

- **Recibos (hasta el 31/12/2026)** se hacen en **Argos** y se cargan en la app (Recibos → «Cargar listado de Argos», PDF o Excel de Albaranes). Se emparejan por número `A26/…`.
- **Recibos HX** (serie `HX26-0001…`, `origen:"app"`): los crea la propia app (`recibosHX()` en `index.html`) en el navegador de dirección o de recepción al marcar «Asistió»: horas extra (prueba con Laura hasta 2026; todos desde 2027) y **clases sueltas** (desde el 23/11/2026, un recibo por clase; ver abajo).
- **Clases sueltas** (`alumnos.sueltas = {profes, precio}`): al marcar «Asistió» se crea el HX; se manda por WhatsApp desde Recibos; recepción hace el mismo recibo a mano en Argos (misma fecha, concepto «clase suelta»); al cargar el listado de Argos se juntan (`argos` en el HX) y al cargar la caja de Argos (Gastos) queda pagado (`hxPagadosCajaArgos`). En 2027: acumular las clases en el mismo recibo mientras no esté pagado.
- **Facturación (hasta 31/12/2026)** la hace **Argos**. La app sube las facturas de Argos (Gastos → «Subir facturas de venta de Argos (PDF)») y cuadra banco ↔ Argos (Facturación). Desde 2027: facturas simplificadas de la app (Facturación semanal), una por recibo pagado; el efectivo se factura al ingresarlo.
- **Gastos y banco:** se sube el extracto del Sabadell (.xls); categorías con aprendizaje; justificantes en PDF/foto.
- **Caja:** de prueba en 2026; real desde el 1/1/2027 (`CAJA_REAL_DESDE`).
- **Fichajes:** activos desde el 1/1/2027 (`FICH_DESDE`).
- **Cobros pendientes** (mostrador y dirección): alumnos que vienen hoy con recibos pendientes, buscador, «Para reclamar» (2 o más pendientes, WhatsApp; se apunta en `waRec.reclamo`) y «Esperando beca» aparte.
- **Avisos de las profesoras:** desde la ficha («Avisar a dirección y a Ainea»), con plantillas; la pestaña «Avisos» calcula el ajuste del recibo del mes (clases que quedan × precio de la hora del nivel) y dice qué hacer en Argos; se cierran con una nota que ve la profesora.
- **Copia de seguridad:** Accesos → Copia de seguridad → «Descargar copia completa»: .zip con datos (JSON), código (`app/`), reglas, plan, este manual, programa de restauración y, si se marca, los PDF y fotos.

Fechas clave en el código: `ATR_DESDE` (atrasados desde 1/10/2026), `FE_PRUEBA_DESDE` (facturas de prueba desde 1/11/2026), `SUE_FIJA_DESDE` (clases sueltas, 23/11/2026), `PD_CAJA_DESDE` (31/12/2026), `CAJA_REAL_DESDE` y `FICH_DESDE` (1/1/2027).

## 6. Alojamiento y publicación

- **GitHub Pages:** cuenta `mostradoraltheaformacion-coder`, repositorio público `horarios-althea`, rama principal, carpeta raíz. Se publica subiendo los archivos («+» → «Subir archivos» → «Confirmar cambios»); tarda 1–2 minutos (≤10 por la caché).
- **DNS** en Loading.es (Plesk): `horarios` CNAME → `mostradoraltheaformacion-coder.github.io`. La web principal (`www`) está en Wix y el correo en Loading: no tocar.
- **Reserva:** Cloudflare Pages `horarios-althea.pages.dev` (se dejó por los bloqueos de IPs de Cloudflare en días de LaLiga; para volver: CNAME `horarios` → `horarios-althea.pages.dev` y añadir el dominio en Cloudflare).
- **Firebase:** proyecto `althea-horarios`, plan gratuito Spark. Las reglas se publican a mano en la consola (Firestore → Reglas), antes que los archivos cuando cambian.

## 7. Restaurar
Ver `restaurar/LEEME.txt`. El programa `restaurar.mjs` (Node.js + firebase-admin, con una clave de cuenta de servicio) escribe todas las colecciones de la copia (convirtiendo las fechas de Firestore), reparte cada alumno en `alumnos` (campos `CORE`) y `privado`, y vuelve a subir los PDF y fotos si la copia los lleva. Los fichajes y facturas se restauran tal cual (el programa no pasa por las reglas). No restaura `cuentas` (dependen de la cuenta de Auth: se vuelven a crear al entrar).

## 8. Decisiones de la titular que conviene conocer

- Facturas, cobros de caja y fichajes **no se pueden borrar ni cambiar**; se corrigen con documentos nuevos (rectificativa, anulación, ajuste).
- Ainea ve recibos y descuadres; recepción solo puede **añadir** recibos, no cambiarlos.
- El repositorio es público: **nunca** subir a GitHub PDFs, Excel del banco, zips ni copias.
- Las notas completas de cada sesión de trabajo están en el proyecto de claude.ai «2 fase de app althea».
